Follow instructions at http://ml.sheffield.ac.uk/~neil/cgi-bin/software/downloadForm.cgi?toolbox=mocap to download the software toolbox from Neal Lawrence.
